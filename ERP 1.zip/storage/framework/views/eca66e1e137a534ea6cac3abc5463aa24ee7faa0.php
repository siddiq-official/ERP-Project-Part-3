
 
<?php $__env->startSection("content"); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="card-header">
        <h3 class="card-title">Employe List with Status</h3>

        <!-- <div class="card-tools">
          <div class="input-group input-group-sm" style="width: 150px;">
            <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

            <div class="input-group-append">
              <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </div> -->
      </div>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card-body table-responsive p-0">
        <table class="table table-hover DataTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Full Name</th>
              <th>Position</th>
              <th>Phone No</th>
              <th>Phone No (Optonal)</th>
              <th>Email </th>
              <th>Present Address</th>
              <th>Parmanent Address</th>
              <th>View</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $employe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($x->id); ?></td> 
              <td><?php echo e($x->name); ?></td>
              <td><?php echo e($x->position); ?></td>
              <td><?php echo e($x->phone_no); ?></td>
              <td><?php echo e($x->phone_no_optonal); ?></td>
              <td><?php echo e($x->email); ?></td>
              <td><?php echo e($x->present_address); ?></td>
              <td><?php echo e($x->parmanent_address); ?></td>
              <td><?php echo e($x->about); ?></td>
              <td><a href="#">
                    <i class="far fa-eye"></i>
                  </a>
                  <a href="<?php echo e(url('edit_employe'. $x->id)); ?>">
                    <i class="far fa-edit"></i>
                  </a>
                  <a href="#">
                    <i class="fas fa-trash"></i>
                  </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("allpage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\archproject\resources\views/employe_status.blade.php ENDPATH**/ ?>